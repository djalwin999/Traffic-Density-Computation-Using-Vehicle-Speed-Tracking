#
#
# import openai
#
# # Set the OpenAI API key.
# openai.api_key = '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'
#
# response = openai.Completion.create(
#     # Specify the engine (e.g., davinci-codex)
#     engine="davinci-codex",
#
#     # The prompt to complete.
#     prompt="Tell me a joke.",
#
#     # Set the maximum length of the response.
#     max_tokens=30,
# )
#
#
#
# # Print the first choice.
# print(response.choices[0].text.strip())



import openai

# Set up your API key
openai.api_key = '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'

# Generate a text completion
response = openai.Completion.create(
  engine="text-davinci-003",
  prompt="",
  max_tokens=50
)

print(response.choices[0].text.strip())
